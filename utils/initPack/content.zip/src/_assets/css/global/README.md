Arquivos colocados nesta pasta serão carregados
automaticamente  no escopo global  do sistema e
poderão ser acessados a partir de qualquer tela